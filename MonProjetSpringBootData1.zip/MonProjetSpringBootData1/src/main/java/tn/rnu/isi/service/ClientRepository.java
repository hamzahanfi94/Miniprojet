package tn.rnu.isi.service;
 

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

import tn.rnu.isi.model.Commande;
import tn.rnu.isi.model.Produit;
import tn.rnu.isi.model.Client;


 

 
 
public interface ClientRepository extends CrudRepository <Client, Long>{
	
 
	Client findByIdClient(Long idClient);
	
	 
	List<Client> findAll();
	
	Client save (Client client);
	 
	@Modifying
	@Query("update Client u set u.idClient = ?1")
	int updateIdClient(Long idClient);
	
	@Modifying
	@Query("update Client u set u.loginClient = ?1, u.motPasseClient = ?2 , u.nomClient = ?3  , u.prenomClient = ?4  "
			+ ", u.civiliteClient = ?5  , u.dateNaissanceClient = ?6  , u.numeroAdrClient = ?7  , u.rueAdrClient = ?8"
			+ "  , u.communeAdrClient = ?9  , u.villeAdrClient = ?10  , u.cpAdrClient = ?11  "
			+ ", u.telClient = ?12  , u.faxClient = ?13  , u.gsmClient = ?14  , u.emailClient = ?15 where u.idClient = ?16")
	int updateDesigClient(String loginClient, String motPasseClient, String nomClient
			, String prenomClient , String civiliteClient , String dateNaissanceClient , String numeroAdrClient
			, String rueAdrClient , String communeAdrClient , String villeAdrClient , String cpAdrClient 
			, String telClient , String faxClient , String gsmClient , String emailClient, Long  idClient);

	@Transactional
 	@Modifying
	@Query("delete from Client u where u.idClient = ?1")
	void delete(Long idClient);
  
 	
 	

}